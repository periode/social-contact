package polsys;

import processing.core.PApplet;

public class ProcessingObject {
	
	public static PApplet p;

}
